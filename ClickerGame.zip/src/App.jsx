import { useState } from 'react'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Clicker Game</h1>
      <p>Кліків: {count}</p>
      <button onClick={() => setCount(count + 1)}>Клікни мене</button>
    </div>
  )
}

export default App
