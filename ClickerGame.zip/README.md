# Clicker Game

Мінімальна гра-клікер на React + Vite.
